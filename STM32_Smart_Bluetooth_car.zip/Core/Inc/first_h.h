#ifndef __first_H
#define __first_H

void red(void);
void gree(void);
void bule(void);
void forward(int a, int b);
void backward(int c, int d);
void stop(int e, int f);
#endif
