#ifndef FONT_H
#define FONT_H

#include "stdint.h"

typedef struct {
	uint8_t Data[16];
	uint8_t Index;
}FNT_EN8X16_t;

typedef struct {
	uint8_t Data[32];
	uint8_t Index[3];
}FNT_CN16X16_t;

uint8_t * Find_CN(uint8_t * pIndex);
uint8_t * Find_EN(uint8_t * pIndex);

#endif
