/*
 * @Description: [MCU]STM32F407	[HAL��]v1.8.0	[�ӿ�]I2C	[����IC]SSD1306
 * @Date: 2023-01-28 09:42:34
 * @LastEditTime: 2023-02-03 11:39:04
 * @Author: Nixya
 * @Company: HuaQingYuanJian
 * @�������: ���Դ��л���ȫ��ͼ����ˢ�µ���Ļ
 */

#include "oled.h"

/**
 * @brief: �Դ�
 */
uint8_t OLED_GDATA[8][128]={0};

/**
 * @brief: ����1�ֽ�ָ��
 */
void OLED_T_CMD1(uint8_t CMD)
{
	uint8_t sCMD[]={OLED_CMDR,CMD};
	HAL_I2C_Master_Transmit(&OLED_PORT,OLED_ADDR,sCMD,2,OLED_TIMEOUT);
}

/**
 * @brief: ����2�ֽ�ָ��
 */
void OLED_T_CMD2(uint8_t CMD1,uint8_t CMD2)
{
	uint8_t sCMD[]={OLED_CMDR,CMD1,CMD2};
	HAL_I2C_Master_Transmit(&OLED_PORT,OLED_ADDR,sCMD,3,OLED_TIMEOUT);
}

/**
 * @brief: ����3�ֽ�ָ��
 */
void OLED_T_CMD3(uint8_t CMD1,uint8_t CMD2,uint8_t CMD3)
{
	uint8_t sCMD[]={OLED_CMDR,CMD1,CMD2,CMD3};
	HAL_I2C_Master_Transmit(&OLED_PORT,OLED_ADDR,sCMD,4,OLED_TIMEOUT);
}

/**
 * @brief: ����1�ֽ�����
 * @param {uint8_t} Data
 */
void OLED_T_DAT1(uint8_t Data)
{
	uint8_t sData[]={OLED_DATR,Data};
	HAL_I2C_Master_Transmit(&OLED_PORT,0x78,sData,2,OLED_TIMEOUT);
}


void OLED_T_DAT(uint8_t* pdata,uint16_t len)
{
	uint8_t reg=OLED_DATR;
	HAL_I2C_Master_Transmit(&OLED_PORT,0x78,&reg,1,OLED_TIMEOUT);
	HAL_I2C_Master_Transmit(&OLED_PORT,0x78,pdata,len,OLED_TIMEOUT);
}

/**
 * @brief: ����Ѱַģʽ
 * @param {uint8_t} Mode:[0]ˮƽѰַ[1]��ֱѰַ[2]ҳѰַģʽ
 */
void OLED_Conf_AddressingMode(uint8_t Mode)
{
	OLED_T_CMD2(0x20,Mode);
}
#define ADDRESSING_PAGE				2				//0x20,0x02
#define ADDRESSING_VERTICAL		1				//0x20,0x01
#define ADDRESSING_HORIZON		0				//0x20,0x00

/**
 * @brief: ҳѰַ����
 * @param {uint8_t} Page:0~7
 * @param {uint8_t} ColL:0~15
 * @param {uint8_t} ColH:0~15
 * @param {uint8_t} Line:0~7
 */
void OLED_Conf_AddressingPage(uint8_t Page,uint8_t ColL,uint8_t ColH,uint8_t Line)
{
	OLED_T_CMD1(0xB0+Page);
	OLED_T_CMD1(ColL);
	OLED_T_CMD1(0x10+ColH);
	OLED_T_CMD1(0x40+Line);
}

/**
 * @brief: ˮƽ/��ֱѰַ����
 * @param {uint8_t} PageS:0~7
 * @param {uint8_t} PageE:0~7
 * @param {uint8_t} ColS:0~127
 * @param {uint8_t} ColE:0~127
 */
void OLED_Conf_AddressingHV(uint8_t PageS,uint8_t PageE,uint8_t ColS,uint8_t ColE)
{
	OLED_T_CMD3(0x21,PageS,PageE);OLED_T_CMD3(0x21,ColS,ColE);
}

/**
 * @brief: �������Աȶ�
 * @param {uint8_t} Level:0~255
 */
void OLED_Conf_Contrast(uint8_t Level)
{
	OLED_T_CMD2(0x81,Level);
}

/**
 * @brief: ȫ��ģʽ
 * @param {uint8_t} Mode:[0]ȫ��[1]����
 */
void OLED_Conf_FullLightMode(uint8_t Mode)
{
	if(Mode){OLED_T_CMD1(0xA4);}else{OLED_T_CMD1(0xA5);}
}
#define FULLLIGHT_ON	0
#define FULLLIGHT_OFF	1

/**
 * @brief: ��ɫģʽ
 * @param {uint8_t} Mode:[0]����[1]��ɫ
 */
void OLED_Conf_ColorInvers(uint8_t Mode)
{
	if(Mode){OLED_T_CMD1(0xA7);}else{OLED_T_CMD1(0xA6);}
}
#define COLOR_NORMAL		0
#define COLOR_INVERSE		1


/**
 * @brief: ��忪��
 * @param {uint8_t} Mode[0]��[1]��
 */
void OLED_Conf_PanelPower(uint8_t Mode)
{
	if(Mode){OLED_T_CMD1(0xAF);}else{OLED_T_CMD1(0xAE);}
}
#define PANEL_OFF	0
#define PANEL_ON	1

/**
 * @brief: ����GDDRAMӳ����ʼ��
 * @param {uint8_t} Line
 */
void OLED_Conf_StartLine(uint8_t Line)
{
	OLED_T_CMD1(Line+0x40);
}

/**
 * @brief: ����SEG/Colӳ���ϵ
 * @param {uint8_t} Mode[0]����[1]��ת
 */
void OLED_Conf_SEGMapping(uint8_t Mode)
{
	if(Mode){OLED_T_CMD1(0xA1);}else{OLED_T_CMD1(0xA0);}
}
#define SEGMAPPING_NORMAL			0
#define SEGMAPPING_INVERSE		1

/**
 * @brief: ����COM/Lineӳ���ϵ
 * @param {uint8_t} Mode[0]����[1]��ת
 */
void OLED_Conf_COMMapping(uint8_t Mode)
{
	if(Mode){OLED_T_CMD1(0xC0);}else{OLED_T_CMD1(0xC8);}
}
#define COMMAPPING_NORMAL			0
#define COMMAPPING_INVERSE		1


/**
 * @brief: ����COM������
 * @param {uint8_t} MuxRatio:1~64? 0~63
 */
void OLED_Conf_MuxRatio(uint8_t MuxRatio)
{
	OLED_T_CMD2(0xA8,MuxRatio);
}
#define MUXRATIO_DEFAULT 63

/**
 * @brief: ������ƫ��
 * @param {uint8_t} Skew:0~63
 */
void OLED_Conf_LineSkew(uint8_t Skew)
{
	OLED_T_CMD2(0xD3,Skew);
}

/**
 * @brief: ����ӳ��ģʽ
 * @param {uint8_t} Mode1
 * @param {uint8_t} Mode2
 */
void OLED_Conf_COMMode(uint8_t Mode1,uint8_t Mode2)
{
	uint8_t Conf = 0x02;
	if(Mode1){Conf |= 0x20;}
	if(Mode2){Conf |= 0x10;}
	OLED_T_CMD2(0xDA,Conf);
}

/**
 * @brief: ����ˢ����
 */
void OLED_Conf_FPS(void)
{
	OLED_T_CMD2(0xD5,0xF0);//0x80?
}

//--set pre-charge period
//--set Pre-Charge as 15 Clocks & Discharge as 1 Clock
void OLED_Conf_PCP(void)
{
	OLED_T_CMD2(0xD9,0x22);
}

//--set vcomh
//--set VCOM Deselect Level
void OLED_Conf_Vcom(void)
{
	OLED_T_CMD2(0xDB,0x40);
}


void OLED_Conf_Charge(uint8_t State)
{
	if(State){OLED_T_CMD2(0x8D,0x14);}else{OLED_T_CMD2(0x80,0x10);}
}
#define CHARGE_ON		1
#define CHARGE_OFF	0

/**
 * @brief: ����Դ�
 */
void OLED_ClearGDATA(void)
{
	uint8_t i,j;
	for(i=0;i<8;i++){for(j=0;j<128;j++){OLED_GDATA[i][j]=0;}}
}

/**
 * @brief: ˢ���Դ����ݵ���Ļ
 */
void OLED_Refresh(void)
{
	uint8_t Page,Col;
	for(Page=0;Page<8;Page++)
	{
		OLED_Conf_AddressingPage(Page,0,0,0);
		for(Col=0;Col<128;Col++){OLED_T_DAT1(OLED_GDATA[Page][Col]);}
	}
}

/**
 * @brief: �����Ļ
 */
void OLED_ClearGDDRAM()
{
	OLED_ClearGDATA();
	OLED_Refresh();
}

/**
 * @brief: OLED����ʼ��
 */
void OLED_Init()
{
	HAL_Delay(100);
	OLED_Conf_PanelPower			(PANEL_OFF);
	OLED_Conf_AddressingMode	(ADDRESSING_PAGE);
	OLED_Conf_AddressingPage	(0,0,0,0);
	OLED_Conf_COMMapping			(COMMAPPING_NORMAL);
	OLED_Conf_Contrast				(255);
	OLED_Conf_SEGMapping			(SEGMAPPING_INVERSE);
	OLED_Conf_ColorInvers			(COLOR_NORMAL);
	OLED_Conf_MuxRatio				(MUXRATIO_DEFAULT);
	OLED_Conf_FullLightMode		(FULLLIGHT_OFF);
	OLED_Conf_LineSkew				(0);
	OLED_Conf_FPS							();
	OLED_Conf_PCP							();
	OLED_Conf_COMMode					(0,1);
	OLED_Conf_Vcom						();
	OLED_Conf_Charge					(CHARGE_ON);
	OLED_Conf_PanelPower			(PANEL_ON);
	OLED_ClearGDDRAM					();
}

void OLED_Init_QV()
{
	HAL_Delay(100);
	OLED_T_CMD1(0xAE);
	OLED_T_CMD2(0x20,0x10);
	OLED_T_CMD1(0xB0);
	OLED_T_CMD1(0x00);
	OLED_T_CMD1(0x10);
	OLED_T_CMD1(0x40);
	OLED_T_CMD1(0xC8);
	OLED_T_CMD2(0x81,0xFF);
	OLED_T_CMD1(0xA1);
	OLED_T_CMD1(0xA6);
	OLED_T_CMD2(0xA8,0x3F);
	OLED_T_CMD1(0xA4);
	OLED_T_CMD2(0xD3,0x00);
	OLED_T_CMD2(0xD5,0xF0);//0x80?
	OLED_T_CMD2(0xD9,0x22);
	OLED_T_CMD2(0xDA,0x12);
	OLED_T_CMD2(0xDB,0x40);//0x20?
	OLED_T_CMD2(0x8D,0x14);
	OLED_T_CMD1(0xAF);
	OLED_ClearGDDRAM();
}

/**
 * @brief: ����ָ����״̬
 * @param {uint8_t} x:0~127
 * @param {uint8_t} y:0~63
 * @param {uint8_t} State:[0]��[1]��
 * @return {*}
 */
void OLED_Set_Point(uint8_t x,uint8_t y,uint8_t State)
{
	
	#if 1
	uint8_t Page,Column,Line,SEG;
	Page=y/8;
	Column=x;
	Line=y%8;
	SEG=0x01;
	if((x>128)||(y>64)){return;}
	if(State)
	{
		OLED_GDATA[Page][Column] |= (SEG<<=Line);
	}
	else
	{
		OLED_GDATA[Page][Column] &= ~(SEG<<=Line);
	}
	#else

	if((x>128)||(y>64))return;
	if(State){OLED_GDATA[y/8][x] |= (1<<(y%8));}
	else{OLED_GDATA[y/8][x] &= ~(1<<(y%8));}

	#endif
}

uint8_t  OLED_Get_Point(uint8_t x,uint8_t y,uint8_t * Data)
{
		return ( (Data[(x+y*8)]>>(y%8)) & 1);
}


//x=0~7;y=0~3
void OLED_Set_BMP16x16(uint8_t x,uint8_t y,uint8_t * Data)
{
	for(uint8_t page=0;page<2;page++)
	{
		for(uint8_t col=0;col<16;col++)
		{
			for(uint8_t line=0;line<8;line++)
			{
				if((x<128) && ((y+page*8) < 64))
				{
					OLED_Set_Point(x+col,y+line+page*8,Data[page*16+col] >> line & 1);
				}
			}
		}
	}
}

//x=0~15;y=0~3
void OLED_Set_BMP8x16(uint8_t x,uint8_t y,uint8_t * Data)
{
	for(uint8_t page=0;page<2;page++)
	{
		for(uint8_t col=0;col<8;col++)
		{
			for(uint8_t line=0;line<8;line++)
			{
				if((x<128) && ((y+page*8) < 64))
				{
					OLED_Set_Point(x+col,y+line+page*8,Data[page*8+col] >> line & 1);
				}
			}
		}
	}
}

void OLED_Set_CN16x16(uint8_t x,uint8_t y,uint8_t * pChar)
{
	if(x>127 || y>63)return;
	while(pChar[0] != '\0')
	{OLED_Set_BMP16x16(x,y,Find_CN(pChar));x+=16;pChar+=2;}
}

void OLED_Set_EN8x16(uint8_t x,uint8_t y,uint8_t * pChar)
{
	while(pChar[0] != '\0')
	{OLED_Set_BMP8x16(x,y,Find_EN(pChar));pChar++;x+=8;}
}

/**
 * @brief: ��GRAM������һ���ַ���
 * @param {uint8_t} x
 * @param {uint8_t} y
 * @param {uint8_t *} pChar
 */
void OLED_Set_String(uint8_t x,uint8_t y,uint8_t * pChar)
{
	if(x>127 || y>63)return;
	while(*pChar != '\0')
	{
		if(*pChar >= 0x80)
		{OLED_Set_BMP16x16(x,y,Find_CN(pChar));x+=16;pChar+=3;}
		else
		{OLED_Set_BMP8x16(x,y,Find_EN(pChar));x+=8;pChar+=1;}		
	}
}

void OLED_Set_BMP(uint8_t x,uint8_t y,uint8_t w,uint8_t h,uint8_t* BMP)
{
	for(uint8_t i=0;i<w;i++)
	{
		for(uint8_t j=0;j<h;j++)
		{
			OLED_Set_Point(x+i,y+j,OLED_Get_Point(i,j,BMP));
		}
	}
}

void OLED_Set_BMPFull(uint8_t* Data)
{
	for(uint8_t i=0;i<8;i++)
	{
		for(uint8_t j=0;j<128;j++)
		{
			OLED_GDATA[i][j] = Data[i*128+j];
		}
	}
}
